"""
L2 Dashboard — Gerador de dados
================================
Uso:
    python update.py --boletos boletos.xlsx --estoque estoque.xlsx

Gera o arquivo data.json que alimenta o dashboard no GitHub Pages.

Dependências:
    pip install pandas openpyxl
"""

import re
import math
import json
import argparse
from datetime import date
from pathlib import Path


# ── Helpers ───────────────────────────────────────────────────────────────────

def parse_estoque_val(v):
    """Trunca o 3º dígito após a vírgula (lógica do relatório base)."""
    try:
        return math.floor(float(str(v).strip()) * 100) / 100
    except Exception:
        return 0.0

def parse_boleto_val(v):
    try:
        return round(float(str(v).strip()), 2)
    except Exception:
        return 0.0

def clean_html(s):
    return re.sub(r'\s+', ' ', re.sub(r'<[^>]+>', '', str(s))).strip()


# ── Parse boletos ──────────────────────────────────────────────────────────────

def parse_boletos(path):
    path = Path(path)
    if path.suffix.lower() in ('.xlsx', '.xls') and path.suffix.lower() != '.xls':
        import pandas as pd
        df = pd.read_excel(path, sheet_name=0, header=None, dtype=str)
        df = df.fillna('')
        rows = [list(row) for _, row in df.iterrows()]
    else:
        # HTML disfarçado de .xls
        try:
            import pandas as pd
            df = pd.read_excel(path, sheet_name=0, header=None, dtype=str)
            df = df.fillna('')
            rows = [list(row) for _, row in df.iterrows()]
        except Exception:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            trs = re.findall(r'<tr[^>]*>(.*?)</tr>', content, re.DOTALL | re.IGNORECASE)
            rows = []
            for tr in trs:
                tds = re.findall(r'<td[^>]*>(.*?)</td>', tr, re.DOTALL | re.IGNORECASE)
                rows.append([clean_html(td) for td in tds])

    SKIP = {'Valor', 'CPF/CNPJcliente', 'fornecedor'}
    result = {0: {'name': 'Compra mercadão zenrelia', 'total': 0.0}}
    fornecedor_atual = None
    last_no_cnpj = None

    def flush():
        nonlocal fornecedor_atual, last_no_cnpj
        if fornecedor_atual and last_no_cnpj is not None:
            if fornecedor_atual == '-':
                result[0]['total'] = round(result[0]['total'] + last_no_cnpj, 2)
            else:
                code = int(re.match(r'^(\d+)', fornecedor_atual).group(1))
                result[code]['total'] = round(result[code]['total'] + last_no_cnpj, 2)
        fornecedor_atual = None
        last_no_cnpj = None

    for row in rows:
        if not row:
            continue
        val0 = str(row[0]).strip()
        col1 = str(row[1]).strip() if len(row) > 1 else ''

        if val0 == '' and col1 == '':
            flush()
            continue
        if val0 in SKIP or val0 == 'nan':
            continue
        if val0 == '-':
            fornecedor_atual = '-'
            last_no_cnpj = None
            continue
        if re.match(r'^\d+ - ', val0):
            fornecedor_atual = val0
            last_no_cnpj = None
            code = int(re.match(r'^(\d+)', val0).group(1))
            name = val0.split(' - ', 1)[1].strip()
            if code not in result:
                result[code] = {'name': name, 'total': 0.0}
            continue
        try:
            v = round(float(val0), 2)
            if col1 == '' and fornecedor_atual:
                last_no_cnpj = v
        except Exception:
            pass

    flush()
    return {k: v for k, v in result.items() if v['total'] > 0}


# ── Parse estoque ──────────────────────────────────────────────────────────────

def parse_estoque(path):
    path = Path(path)
    try:
        import pandas as pd
        df = pd.read_excel(path, sheet_name=0, header=None, dtype=str)
        df = df.fillna('')
        rows_raw = [list(row) for _, row in df.iterrows()]
        def get_row(r):
            col0 = str(r[0]).strip() if len(r) > 0 else ''
            col1 = str(r[1]).strip() if len(r) > 1 else ''
            return col0, col1
    except Exception:
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        trs = re.findall(r'<tr[^>]*>(.*?)</tr>', content, re.DOTALL | re.IGNORECASE)
        rows_raw = []
        for tr in trs:
            tds = re.findall(r'<td[^>]*>(.*?)</td>', tr, re.DOTALL | re.IGNORECASE)
            rows_raw.append([clean_html(td) for td in tds])
        def get_row(r):
            col0 = str(r[0]).strip() if len(r) > 0 else ''
            col1 = str(r[1]).strip() if len(r) > 1 else ''
            return col0, col1

    result = {}
    fornecedor_atual = None
    ignorar = False

    for r in rows_raw:
        col0, col1 = get_row(r)
        if re.match(r'^\d+ - ', col0):
            fornecedor_atual = col0
            ignorar = False
            code = int(re.match(r'^(\d+)', col0).group(1))
            name = col0.split(' - ', 1)[1].strip()
            if code not in result:
                result[code] = {'name': name, 'total': 0.0}
        elif 'NÃO DEFINIDO' in col0.upper():
            ignorar = True
        elif col0 == 'Total agrupamento:' and not ignorar and fornecedor_atual:
            code = int(re.match(r'^(\d+)', fornecedor_atual).group(1))
            result[code]['total'] = round(result[code]['total'] + parse_estoque_val(col1), 2)

    return {k: v for k, v in result.items() if v['total'] > 0}


# ── Regras de consolidação ────────────────────────────────────────────────────

# Simples: código_origem → código_destino (origem some)
CONSOLIDAR_SIMPLES = {
    175: 191,   # ADIMAX-175    → ADIMAX-191
    40:  113,   # GLA-40        → GLA-113
    161: 192,   # INTERSUL-161  → INTERSUL-192
}

# Múltiplos: lista de códigos → (chave_display, nome_display)
CONSOLIDAR_MULTI = [
    ([58, 158, 168], "58 / 158 / 168", "NUTRISANTOS ALIMENTACAO ANIMAL LTDA"),
    ([79, 166],      "79 / 166",       "VET-RIO COMERCIO EIRELI"),
    ([173, 205],     "173 / 205",      "NEOVIA NUTRICAO E SAUDE ANIMAL LTDA"),
    ([43, 182],      "43 / 182",       "INNOVAT/ANIMALEVET"),
    ([152, 177],     "152 / 177",      "GIFT 4 PET/LOJA DE FÁBRICA"),
]


def apply_consolidations(ap, estoque):
    # Simples
    for origem, destino in CONSOLIDAR_SIMPLES.items():
        for d in (ap, estoque):
            if origem in d:
                if destino not in d:
                    d[destino] = {'name': d[origem]['name'], 'total': 0.0}
                d[destino]['total'] = round(d[destino]['total'] + d[origem]['total'], 2)
                del d[origem]

    # Multi-código
    for codigos, cod_display, nome_display in CONSOLIDAR_MULTI:
        for d in (ap, estoque):
            total = sum(d.get(c, {'total': 0.0})['total'] or 0.0 for c in codigos)
            for c in codigos:
                if c in d:
                    del d[c]
            if total > 0:
                d[cod_display] = {'name': nome_display, 'total': round(total, 2)}

    return ap, estoque


# ── Main ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='Gera data.json para o L2 Dashboard')
    parser.add_argument('--boletos', required=True, help='Relatório de boletos (.xls ou .xlsx)')
    parser.add_argument('--estoque', required=True, help='Relatório de estoque (.xls ou .xlsx)')
    parser.add_argument('--out', default='data.json', help='Arquivo de saída (padrão: data.json)')
    args = parser.parse_args()

    print(f'📄 Lendo boletos:  {args.boletos}')
    ap = parse_boletos(args.boletos)

    print(f'📄 Lendo estoque:  {args.estoque}')
    estoque = parse_estoque(args.estoque)

    print('🔀 Aplicando consolidações...')
    ap, estoque = apply_consolidations(ap, estoque)

    total_ap  = sum(v['total'] or 0 for v in ap.values())
    total_est = sum(v['total'] or 0 for v in estoque.values())
    print(f'   C. a pagar: R$ {total_ap:,.2f}  ({len(ap)} fornecedores)')
    print(f'   Estoque:    R$ {total_est:,.2f}  ({len(estoque)} fornecedores)')

    # Montar lista de fornecedores
    all_keys = sorted(
        [k for k in set(list(ap.keys()) + list(estoque.keys())) if isinstance(k, int)]
    ) + sorted(
        [k for k in set(list(ap.keys()) + list(estoque.keys())) if isinstance(k, str)]
    )

    suppliers = []
    for k in all_keys:
        ap_entry  = ap.get(k)
        est_entry = estoque.get(k)
        suppliers.append({
            'code': k,
            'name': (ap_entry or est_entry)['name'],
            'ap':   ap_entry['total']  if ap_entry  else None,
            'est':  est_entry['total'] if est_entry else None,
        })

    output = {
        'updated':   date.today().isoformat(),
        'total_ap':  round(total_ap, 2),
        'total_est': round(total_est, 2),
        'suppliers': suppliers,
    }

    out_path = Path(args.out)
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f'\n✅ Arquivo gerado: {out_path}')
    print(f'   Faça commit e push do data.json para atualizar o dashboard.')


if __name__ == '__main__':
    main()
