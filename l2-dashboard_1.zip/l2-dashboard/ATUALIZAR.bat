@echo off
chcp 65001 >nul
title L2 Dashboard — Atualizar Dados

echo.
echo ============================================
echo   L2 DASHBOARD — ATUALIZADOR DE DADOS
echo ============================================
echo.

:: Verificar se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado!
    echo.
    echo Acesse python.org/downloads e instale o Python.
    echo Lembre de marcar "Add Python to PATH" durante a instalacao.
    echo.
    pause
    exit /b
)

:: Verificar se as bibliotecas estão instaladas
python -c "import pandas, openpyxl" >nul 2>&1
if errorlevel 1 (
    echo Instalando bibliotecas necessarias, aguarde...
    pip install pandas openpyxl --quiet
    echo.
)

:: Entrar na pasta onde o .bat está
cd /d "%~dp0"

echo Informe o nome do arquivo de BOLETOS:
echo (coloque o arquivo .xlsx nesta pasta antes de continuar)
echo.
set /p BOLETOS="Boletos: "

echo.
echo Informe o nome do arquivo de ESTOQUE:
set /p ESTOQUE="Estoque: "

echo.
echo Processando...
echo.

python update.py --boletos "%BOLETOS%" --estoque "%ESTOQUE%"

if errorlevel 1 (
    echo.
    echo [ERRO] Algo deu errado. Verifique os nomes dos arquivos e tente novamente.
) else (
    echo.
    echo ============================================
    echo   data.json gerado com sucesso!
    echo ============================================
    echo.
    echo Proximo passo: suba o data.json para o GitHub.
    echo.
)

pause
