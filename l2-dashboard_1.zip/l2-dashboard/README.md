# L2 Dashboard — Financeiro

Dashboard interativo hospedado no GitHub Pages.
Exibe Contas a Pagar × Estoque por fornecedor, com gráficos, filtros e busca.

---

## Estrutura do projeto

```
l2-dashboard/
├── index.html   ← o dashboard (nunca precisa ser alterado)
├── data.json    ← os dados (único arquivo que você atualiza)
├── update.py    ← script que gera o data.json a partir dos relatórios
└── README.md
```

**A lógica é simples:**
- `index.html` lê o `data.json` e monta o dashboard automaticamente
- Você só precisa atualizar o `data.json` rodando o script

---

## Como atualizar os dados

### 1. Instalar dependências (apenas na primeira vez)
```bash
pip install pandas openpyxl
```

### 2. Rodar o script com os novos relatórios
```bash
python update.py --boletos boletos.xlsx --estoque estoque.xlsx
```

O script vai imprimir os totais e gerar um novo `data.json`.

### 3. Enviar o data.json para o GitHub
```bash
git add data.json
git commit -m "Atualiza dados 19/05/2026"
git push
```

O dashboard online é atualizado automaticamente em menos de 1 minuto.

---

## Configuração inicial no GitHub (primeira vez)

1. Crie um repositório no GitHub (ex: `l2-dashboard`)
2. Faça upload de todos os arquivos desta pasta
3. Vá em **Settings → Pages → Branch: main → / (root) → Save**
4. Aguarde ~1 minuto e acesse:
   ```
   https://seu-usuario.github.io/l2-dashboard
   ```

---

## Regras de consolidação ativas

O script aplica automaticamente as seguintes consolidações toda vez que rodar:

### Simples (código eliminado soma ao destino)
| Eliminado | Destino |
|---|---|
| ADIMAX-175 | ADIMAX-191 |
| GLA-40 | GLA-113 |
| INTERSUL-161 | INTERSUL-192 |

### Múltiplos códigos (exibidos juntos)
| Códigos | Nome |
|---|---|
| 58 / 158 / 168 | NUTRISANTOS ALIMENTACAO ANIMAL LTDA |
| 79 / 166 | VET-RIO COMERCIO EIRELI |
| 173 / 205 | NEOVIA NUTRICAO E SAUDE ANIMAL LTDA |
| 43 / 182 | INNOVAT/ANIMALEVET |
| 152 / 177 | GIFT 4 PET/LOJA DE FÁBRICA |

---

## Dependências
- Python 3.8+
- pandas
- openpyxl
